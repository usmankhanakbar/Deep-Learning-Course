import math

# Sigmoid activation function
def sigmoid(x):
    return 1.0 / (1.0 + math.exp(-x))

# Derivative of sigmoid
def sigmoid_prime(x):
    return sigmoid(x) * (1.0 - sigmoid(x))


def predict(input_val, w1, w2, b1, b2):
    h = sigmoid(w1 * input_val + b1)
    output = sigmoid(w2 * h + b2)
    return output


def main():
    # Initialize weights and biases
    w1, w2 = 0.1, 0.2
    b1, b2 = 0.3, 0.4

    # Learning rate
    learning_rate = 0.1

    # Training data
    input_val = 0.2
    target = 0.8

    # Number of epochs
    epochs = 10000

    # Training
    for i in range(epochs):
        # Forward pass
        h = sigmoid(w1 * input_val + b1)
        output = sigmoid(w2 * h + b2)

        # Error
        error = (target - output) ** 2

        # Backpropagation
        d_output = (target - output) * sigmoid_prime(w2 * h + b2)
        d_h = w2 * d_output * sigmoid_prime(w1 * input_val + b1)

        # Update weights
        w2 += learning_rate * d_output * h
        b2 += learning_rate * d_output
        w1 += learning_rate * d_h * input_val
        b1 += learning_rate * d_h

        # Print error every 1000 epochs
        if i % 1000 == 0:
            print(f"Epoch {i}, Error = {error:.6f}")

    print("\nFinal weights and biases:")
    print(f"w1 = {w1:.4f}, w2 = {w2:.4f}")
    print(f"b1 = {b1:.4f}, b2 = {b2:.4f}")

    # Prediction
    print("\n--- Prediction ---")
    
    test_input = 0.2
    prediction = predict(test_input, w1, w2, b1, b2)
    
    print(f"Input: {test_input}")
    print(f"Predicted Output: {prediction:.4f}")


if __name__ == "__main__":
    main()
