import math
import random

# Sigmoid activation
def sigmoid(x):
    return 1.0 / (1.0 + math.exp(-x))

# Sigmoid derivative (IMPORTANT: uses output)
def sigmoid_prime(output):
    return output * (1.0 - output)


def predict(input_val, w1, w2, b1, b2):
    h = sigmoid(w1 * input_val + b1)
    output = sigmoid(w2 * h + b2)
    return output


def main():

    # Random initialization (better learning)
    w1 = random.uniform(-1, 1)
    w2 = random.uniform(-1, 1)
    b1 = random.uniform(-1, 1)
    b2 = random.uniform(-1, 1)

    learning_rate = 0.5
    epochs = 20000

    # Training dataset (multiple samples = better accuracy)
    training_data = [
        (0.1, 0.2),
        (0.2, 0.4),
        (0.3, 0.6),
        (0.4, 0.8),
        (0.5, 1.0)
    ]

    for epoch in range(epochs):

        total_error = 0

        for input_val, target in training_data:

            # Forward pass
            h = sigmoid(w1 * input_val + b1)
            output = sigmoid(w2 * h + b2)

            # Error
            error = target - output
            total_error += error**2

            # Backpropagation
            d_output = error * sigmoid_prime(output)
            d_h = d_output * w2 * sigmoid_prime(h)

            # Update weights
            w2 += learning_rate * d_output * h
            b2 += learning_rate * d_output

            w1 += learning_rate * d_h * input_val
            b1 += learning_rate * d_h

        if epoch % 2000 == 0:
            print(f"Epoch {epoch}, Error = {total_error:.6f}")

    print("\nFinal weights:")
    print("w1 =", w1)
    print("w2 =", w2)
    print("b1 =", b1)
    print("b2 =", b2)


    # Predictions
    print("\n--- Predictions ---")

    test_inputs = [0.1, 0.2, 0.3, 0.4, 0.5]

    for t in test_inputs:
        pred = predict(t, w1, w2, b1, b2)
        print(f"Input: {t:.2f}  →  Prediction: {pred:.4f}")


if __name__ == "__main__":
    main()
