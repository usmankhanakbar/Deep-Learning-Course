import numpy as np

def sigmoid(x):
    return 1 / (1 + np.exp(-x))  # Fixed: Added parentheses

def sigmoid_prime(x):
    return sigmoid(x) * (1 - sigmoid(x))

def train_model(X, y, learning_rate=0.01, epochs=1000):
    # Fixed: Initialize weights and bias correctly for a single neuron
    weights = np.random.rand(X.shape[1])  # One weight per input feature
    bias = np.random.rand(1)  # Single bias value
    # Alternatively, you could use:
    # weights = np.random.randn(X.shape[1]) * 0.01
    # bias = np.random.randn(1) * 0.01
    
    for epoch in range(epochs):
        total_error = 0
        
        for i in range(len(X)):
            # Forward pass - Fixed: Properly compute output for a single neuron
            z = np.dot(X[i], weights) + bias
            output = sigmoid(z)
            
            # Compute error
            error = (output - y[i])**2
            total_error += error
            
            # Backpropagation - Fixed: Correct gradient calculation
            d_error = output - y[i]  # Derivative of loss with respect to output
            d_output = d_error * sigmoid_prime(z)  # Chain rule through sigmoid
            
            # Update weights and bias
            weights -= learning_rate * d_output * X[i]
            bias -= learning_rate * d_output
        
        # Print progress every 100 epochs
        if epoch % 100 == 0:
            print(f"Epoch {epoch}, Average Error: {total_error/len(X)}")

    return weights, bias

# Example usage
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([0, 1, 1, 0])  # XOR problem
weights, bias = train_model(X, y, learning_rate=0.5, epochs=5000)
print("Trained weights:", weights)
print("Trained bias:", bias)

# Prediction
test_input = np.array([1, 0])
output = sigmoid(np.dot(test_input, weights) + bias)
print("Predicted output for [1, 0]:", output)

# Test all XOR inputs
print("\nTesting all inputs:")
for test_input in X:
    output = sigmoid(np.dot(test_input, weights) + bias)
    print(f"{test_input} -> {output}")